package com.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Candidateform {

	@Id
	@GeneratedValue
	private int id;
	private String candidateName;
	private String skill;
	private String interName;
	private String iempcode;
	private String idate;
	private String selection;
	private String roundSelection;
}
