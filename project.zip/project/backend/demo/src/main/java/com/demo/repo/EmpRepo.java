package com.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.entity.EmpDetails;
import com.demo.entity.EmployeeDetails;

public interface EmpRepo extends JpaRepository<EmpDetails, Long>{
	
	EmpDetails findByCandidateName(String name);

}
