package com.demo.entity;


import java.sql.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class EmployeeDetails {


	@Id
	@GeneratedValue
	private int id;
	private String candidateName;
	private String idate;
	private String interName;
	private String Mode;
	private String totalExp;
	private String releventExp;
	private String bu;
	private String skill;
	private String location;
	private String prating;
	private String crating;
	private String hirecomment;
	private String rcomment;
	private String hcomment;
	private String iempcode;
	private String esign;
	private String psdes1;
	private String bjdes2;
	private String kwdes;
	private String ta1;
	private String ta2;
	private String ta3;
	private String ides;
	private String cides;
	private String sdes;
	private String fdes;
	
	
	public String getIdes() {
		return ides;
	}
	public void setIdes(String ides) {
		this.ides = ides;
	}
	public String getCides() {
		return cides;
	}
	public void setCides(String cides) {
		this.cides = cides;
	}
	public String getSdes() {
		return sdes;
	}
	public void setSdes(String sdes) {
		this.sdes = sdes;
	}
	public String getFdes() {
		return fdes;
	}
	public void setFdes(String fdes) {
		this.fdes = fdes;
	}
	public String getKwdes() {
		return kwdes;
	}
	public void setKwdes(String kwdes) {
		this.kwdes = kwdes;
	}
	public String getPsdes1() {
		return psdes1;
	}
	public void setPsdes1(String psdes1) {
		this.psdes1 = psdes1;
	}
	public String getBjdes2() {
		return bjdes2;
	}
	public void setBjdes2(String bjdes2) {
		this.bjdes2 = bjdes2;
	}
	public String getTa1() {
		return ta1;
	}
	public void setTa1(String ta1) {
		this.ta1 = ta1;
	}
	public String getTa2() {
		return ta2;
	}
	public void setTa2(String ta2) {
		this.ta2 = ta2;
	}
	public String getTa3() {
		return ta3;
	}
	public void setTa3(String ta3) {
		this.ta3 = ta3;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public String getIdate() {
		return idate;
	}
	public void setIdate(String idate) {
		this.idate = idate;
	}
	public String getInterName() {
		return interName;
	}
	public void setInterName(String interName) {
		this.interName = interName;
	}
	public String getMode() {
		return Mode;
	}
	public void setMode(String mode) {
		Mode = mode;
	}
	public String getTotalExp() {
		return totalExp;
	}
	public void setTotalExp(String totalExp) {
		this.totalExp = totalExp;
	}
	public String getReleventExp() {
		return releventExp;
	}
	public void setReleventExp(String releventExp) {
		this.releventExp = releventExp;
	}
	public String getBu() {
		return bu;
	}
	public void setBu(String bu) {
		this.bu = bu;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPrating() {
		return prating;
	}
	public void setPrating(String prating) {
		this.prating = prating;
	}
	public String getCrating() {
		return crating;
	}
	public void setCrating(String crating) {
		this.crating = crating;
	}
	public String getHirecomment() {
		return hirecomment;
	}
	public void setHirecomment(String hirecomment) {
		this.hirecomment = hirecomment;
	}
	public String getRcomment() {
		return rcomment;
	}
	public String getIempcode() {
		return iempcode;
	}
	public void setIempcode(String iempcode) {
		this.iempcode = iempcode;
	}
	public void setRcomment(String rcomment) {
		this.rcomment = rcomment;
	}
	public String getHcomment() {
		return hcomment;
	}
	public void setHcomment(String hcomment) {
		this.hcomment = hcomment;
	}
	
	public String getEsign() {
		return esign;
	}
	public void setEsign(String esign) {
		this.esign = esign;
	}
	
	@Override
	public String toString() {
		return "EmployeeDetails [id=" + id + ", candidateName=" + candidateName + ", idate=" + idate + ", interName="
				+ interName + ", Mode=" + Mode + ", totalExp=" + totalExp + ", releventExp=" + releventExp + ", bu="
				+ bu + ", skill=" + skill + ", location=" + location + ", prating=" + prating + ", crating=" + crating
				+ ", hirecomment=" + hirecomment + ", rcomment=" + rcomment + ", hcomment=" + hcomment + ", iempcode="
				+ iempcode + ", esign=" + esign + ", psdes1=" + psdes1 + ", bjdes2=" + bjdes2 + ", kwdes=" + kwdes
				+ ", ta1=" + ta1 + ", ta2=" + ta2 + ", ta3=" + ta3 + ", ides=" + ides + ", cides=" + cides + ", sdes="
				+ sdes + ", fdes=" + fdes + "]";
	}
	
}
	