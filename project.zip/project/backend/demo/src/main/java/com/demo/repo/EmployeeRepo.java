package com.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.entity.EmployeeDetails;

public interface EmployeeRepo extends JpaRepository<EmployeeDetails, Long>{
	
	EmployeeDetails findByCandidateName(String name);
	
	EmployeeDetails findById(int id);

}
