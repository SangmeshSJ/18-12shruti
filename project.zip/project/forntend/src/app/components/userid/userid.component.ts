import { Component, OnInit } from '@angular/core';
import { EmployeeDetails } from 'src/app/model/employeedetails';
import { EmployeedetailsService } from 'src/app/service/employeedetails.service';

@Component({
  selector: 'app-userid',
  templateUrl: './userid.component.html',
  styleUrls: ['./userid.component.css']
})
export class UseridComponent implements OnInit {
  Employees: EmployeeDetails[];
  Employee:EmployeeDetails;
  constructor(private service:EmployeedetailsService) { }

  ngOnInit() {
    this.getEmployee(251);
  }
getEmployee(id:number){
this.service.getEmployee(id).subscribe(res=>{this.Employee=res
  console.log(res);
  console.log(this.Employee)
});
}
}
