import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { EmpdetailsService } from 'src/app/service/empdetails.service';
import { EmpDetails } from 'src/app/model/empdetails';
import { Observable } from 'rxjs';





@Component({
  selector: 'app-l2form',
  templateUrl: './l2form.component.html',
  styleUrls: ['./l2form.component.css']
})
export class L2formComponent implements OnInit {

  employee: EmpDetails = new EmpDetails();
  employees: Observable<EmpDetails[]>;
  l2Form: FormGroup;
  submitted:boolean= false;
  invalidLogin: boolean=false;

  constructor(private formBuilder: FormBuilder, private router: Router,private empDetailsService: EmpdetailsService) { }

  ngOnInit() {
    this.reloadData();
    this.l2Form = this.formBuilder.group({
      cname: ['', Validators.required],
      skills: ['', Validators.required],
      doi: ['', Validators.required],
      texp:['', Validators.required],
      rexp:['', Validators.required],
      psdes1:['', Validators.required],
      odes1:['', Validators.required],
      bsdes1:['', Validators.required],
      cdes1:['', Validators.required],
      dtdes1:['', Validators.required],
      fdes1:['', Validators.required],
      ppdes1:['', Validators.required],
      mdes1:['', Validators.required],
      gdes1:['', Validators.required],
      rdes1:['', Validators.required],
      ename:['', Validators.required],
      hirecomment:['', Validators.required],
      rcomment:['', Validators.required],
      hcomment:['', Validators.required],
      iempcode:['', Validators.required],    
      esign:['', Validators.required]
    
    });


  }
  
  reloadData() {
    this.employees = this.empDetailsService.getemployeeDetailsList();

  }

  save() {
    this.empDetailsService.createEmployeeDetails(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new EmpDetails();
  }

  
  Submit() {
    this.submitted = true;
     this.save();

    // If validation failed, it should return 
    // to Validate again
    if (this.l2Form.invalid) {
    return;
    }


    this.router.navigate(['/home']);
    }
   

}
