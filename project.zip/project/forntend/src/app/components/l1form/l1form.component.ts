import { Component, OnInit, ViewChild, ElementRef} from '@angular/core';
import { Router } from '@angular/router';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { EmployeeDetails } from 'src/app/model/employeedetails';
import { EmployeedetailsService } from 'src/app/service/employeedetails.service';
import { Observable } from 'rxjs';
import { Skill } from 'src/app/model/skills';
import { Mode } from 'src/app/model/mode';
import {ITEMS} from 'src/app/model/modeInt';
import { Rating } from 'src/app/model/rating';
import { Rate } from 'src/app/model/techrating';
import * as jsPDF from 'jspdf';


@Component({
  selector: 'app-l1form',
  templateUrl: './l1form.component.html',
  styleUrls: ['./l1form.component.css']
})

export class L1formComponent implements OnInit {
  employee: EmployeeDetails = new EmployeeDetails();
  employees: Observable<EmployeeDetails[]>;
  ngForm: FormGroup;
  invalidLogin: boolean=false;
  submitted:boolean= false;
  radioSel:any;
  radioSelected:String;
  radioSelectedString:String;
  itemsList: Mode[] = ITEMS;
  ratingList:Rating[] = Rate;
  radioSel1:any;
  radioSelected1:String;
  radioSelectedString1:String;


  textBoxDisabled = true;

  toggle(){
    this.textBoxDisabled = !this.textBoxDisabled;
  }

textBoxDisabled1 = true;

  toggle1(){
    this.textBoxDisabled1 = !this.textBoxDisabled1;
  }
 // define the JSON of data
  public skill: { [key: string]: Object; }[] = [
        { id: 1,name: 'Java', Code: 'JA' },
        { id: 2, name: 'Angular 6', Code: 'AN' },
        { id: 3, name: 'Node Js', Code: 'NJ' },
        {id: 4, name: 'Express Js', Code: 'EJ' },
        { id: 5,name: 'Dotnet', Code: 'DN' },
        { id: 6,name: 'France', Code: 'FR' },
        { id: 7,name: 'Finland', Code: 'FI' },
        { id: 8,name: 'Germany', Code: 'DE' }, 
    ];
 
   // maps the local data column to fields property
    public localFields: Object = { text: 'name', value: 'Code' };
   // set the placeholder to MultiSelect Dropdown input element
    public localWaterMark: string = 'Select Skill';



  list: any = [
    {id: 1, name: 'Not Applicable '},
    {id: 2, name: 'Inadequate / Not Relevant'},
    {id: 3, name: 'Adequate / Reasonably Relevant'},
    {id: 4, name: 'Good / Relevant'},
    {id: 5, name: 'Excellent / Very Relevant'},
    {id: 6, name: 'Outstanding / Ideal fitment'}
  ];
   current = 1;
  log = '';

  logDropdown(id: number): void {
    const NAME = this.list.find((item: any) => item.id === +id).name;
    this.log += `${NAME} \n`;
    console.log(this.log);
    this.employee.prating=this.log;
    // this.employee.crating=this.log;

  }

  // logDropdown1(id: number): void {
  //   const NAME = this.list.find((item: any) => item.id === +id).name;
  //   this.log += `${NAME} \n`;
  //   console.log(this.log);
  //   this.employee.crating=this.log;
  //   // this.employee.crating=this.log;

  // }




  constructor(private formBuilder: FormBuilder, private router: Router, private employeeDetailsService: EmployeedetailsService) {
    this.itemsList = ITEMS;
    this.radioSelected = "item_3";
    this.getSelecteditem();

   }

  getSelecteditem(){
    this.radioSel = ITEMS.find(Mode => Mode.value === this.radioSelected);
     this.radioSelectedString = JSON.stringify(this.radioSel);
   // console.log(this.radioSel   )
   this.employee.mode=this.radioSelectedString;
  //  console.log(this.radioSelectedString)
  }

  onItemChange(item){
    this.getSelecteditem();
   

  }


  ngOnInit() {

      // this.reloadData();

    this.ngForm = this.formBuilder.group({
      cname: ['', Validators.required],
      desc: ['', Validators.required],
      skill: ['', Validators.required],
      flexibility: ['', Validators.required],
      ename: ['', Validators.required],
      ecode: ['', Validators.required],
      doi:['', Validators.required],
      texp:['', Validators.required],
      rexp:['', Validators.required],
      list_name:['', Validators.required],
      location:['', Validators.required],
      hirecomment:['', Validators.required],
      rcomment:['', Validators.required],
      hcomment:['', Validators.required],
      iempcode:['', Validators.required],
      esign:['', Validators.required],
      psdes1:['', Validators.required],
  	 bjdes2:['', Validators.required],
	  kwdes:['', Validators.required],
  	ta1:['', Validators.required],
    ta2:['', Validators.required],
    ta3:['', Validators.required],
    ides:['', Validators.required],
    cides:['', Validators.required],
    sdes:['', Validators.required],
    fdes:['', Validators.required],
	
    });
  }

  // reloadData() {
  //   this.employees = this.employeeDetailsService.getemployeeDetailsList();

  // }
  // newEmployeeDetails(): void {
  //   this.submitted = false;
  //   this.employee = new EmployeeDetails();
  // }

  save() {
    this.employeeDetailsService.createEmployeeDetails(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new EmployeeDetails();
  }

//   @ViewChild('content') content: ElementRef;
//  makePdf(){

//   let doc = new jsPDF();
//   doc.addHTML(this.content.nativeElement, function() {
//      doc.save("obrz.pdf");

//      console.log("ab");
//   });
 

@ViewChild('content') content: ElementRef;
 makePdf(){

  let doc = new jsPDF();
  doc.addHTML(this.content.nativeElement, function() {
     doc.save("obrz.pdf");

     console.log("ab");
  });
 

 }
  onSubmit() {

    this.submitted= true;
    this.save();
    console.log("xyz");
    // this.makePdf();
    console.log("abc");
   
  // If validation failed, it should return
  // to Validate again
  if (this.ngForm.invalid) {
  return true;
  }
  
   this.router.navigate(['/form']);
  


 

  }
}