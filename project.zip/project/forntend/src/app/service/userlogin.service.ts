import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Login} from '../model/userlogin';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserloginService {

  //  baseurl: string= "  http://localhost:8000";
  private baseUrl = 'http://localhost:8000';
  

  constructor(private http:HttpClient) { }

  // Login(Login:Login){
  //   return this.http.post(this.baseurl,Login);
  // }
  
  getAdmin(login:Login){
    return this.http.post(this.baseUrl + '/login',login);
  }

  
  getByUsename(userName: String): Observable<any> {
    return this.http.get(`${this.baseUrl}/getusername/${userName}`);
  }

   
  //return this.http.get<User>(`detail/${username}`, options); 
  

}
